PhotoNotes_YUANZIQING - 学号 2406033347 - 包名 com.midterm.photonotes.yuanzhiqing
功能：笔记并可附图片（演示）。