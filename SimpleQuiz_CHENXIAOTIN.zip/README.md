SimpleQuiz_CHENXIAOTIN - 学号 2406033309 - 包名 org.midterm.quiz.chenxiaotin
功能：简单三题问答。