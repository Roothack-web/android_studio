ProfileAdmin_NIEYUHANG - 学号 2406033346 - 包名 com.example.profile.nieyuhang
功能：登录/注册/管理员页面。